# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'tuangou.ui'
#
# Created: Fri Nov 26 00:01:44 2010
#      by: PyQt4 UI code generator 4.5.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_mainWidget(object):
    def setupUi(self, mainWidget):
        mainWidget.setObjectName("mainWidget")
        mainWidget.resize(561, 590)
        self.downBtn = QtGui.QPushButton(mainWidget)
        self.downBtn.setGeometry(QtCore.QRect(390, 20, 131, 31))
        self.downBtn.setObjectName("downBtn")
        self.titleLabel = QtGui.QLabel(mainWidget)
        self.titleLabel.setGeometry(QtCore.QRect(30, 70, 501, 101))
        self.titleLabel.setObjectName("titleLabel")
        self.priceLabel = QtGui.QLabel(mainWidget)
        self.priceLabel.setGeometry(QtCore.QRect(30, 520, 131, 31))
        self.priceLabel.setObjectName("priceLabel")
        self.goBtn = QtGui.QPushButton(mainWidget)
        self.goBtn.setGeometry(QtCore.QRect(420, 520, 91, 31))
        self.goBtn.setObjectName("goBtn")
        self.layoutWidget = QtGui.QWidget(mainWidget)
        self.layoutWidget.setGeometry(QtCore.QRect(30, 20, 201, 41))
        self.layoutWidget.setObjectName("layoutWidget")
        self.horizontalLayout = QtGui.QHBoxLayout(self.layoutWidget)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtGui.QLabel(self.layoutWidget)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.listCombo = QtGui.QComboBox(self.layoutWidget)
        self.listCombo.setObjectName("listCombo")
        self.horizontalLayout.addWidget(self.listCombo)
        self.imgLabel = QtGui.QLabel(mainWidget)
        self.imgLabel.setGeometry(QtCore.QRect(30, 200, 500, 300))
        self.imgLabel.setObjectName("imgLabel")

        self.retranslateUi(mainWidget)
        QtCore.QMetaObject.connectSlotsByName(mainWidget)

    def retranslateUi(self, mainWidget):
        mainWidget.setWindowTitle(QtGui.QApplication.translate("mainWidget", "我的团购", None, QtGui.QApplication.UnicodeUTF8))
        self.downBtn.setText(QtGui.QApplication.translate("mainWidget", "下载今日团购信息", None, QtGui.QApplication.UnicodeUTF8))
        self.goBtn.setText(QtGui.QApplication.translate("mainWidget", "前往团购页面", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("mainWidget", "选择团购网站:", None, QtGui.QApplication.UnicodeUTF8))

import tuangou_rc
